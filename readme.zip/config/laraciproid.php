<?php

return [
    'city' => 'cities',
    'province' => 'provinces',
];
